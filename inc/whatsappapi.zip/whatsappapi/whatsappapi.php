<?php
/*
Plugin Name: Whatsapp Api
Description: Basic Whatsapp connection plugin 
Author: Mohamed YAssin
Author URI:  https://www.freelancer.com/u/tryagain3
*/
define('inc',plugin_dir_path(__FILE__ ).'/inc/');
define('jsons_folder','jsons');

$understrap_includes = array(
	'base_functions',
	'admin_pages',
	'admin_pages_functions',
);


foreach ( $understrap_includes as $file ) {
	$path =  inc.$file.".php";
	if(is_file($path)){
		include_once($path);
	}else {
		echo "not found :  $path  </br>";
	}
}