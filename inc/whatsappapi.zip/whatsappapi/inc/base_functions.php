<?php
function pre($array , $title= ''){
	echo "<h3>$title</h3><pre>";
	print_r ($array);
	echo "</pre></br>";
};
function text( $text= NULL){
	global $post_owner;
	global $post_screen;
	global $post_process;

	if ($text == NULL) {
		echo "<h6 style='color: white'> A long text to be shown in places when you can't see results so perhaps you will need to make a standard check . You can serchh for me in the page with sssss .</h6>";
	}else {
		echo "<h3 style='color: white'> $text </h3>";
	}
};
function is_local(){
	if ($_SERVER['REMOTE_ADDR']=='127.0.0.1' || $_SERVER['REMOTE_ADDR']=='::1') {
		return TRUE;
	}
};
function get_json($file){
	$content = file_get_contents(jsons_folder."/$file.json");
	return(json_decode($content, true));
};
function mk_json($fields,$json_file){
	$fp = fopen(jsons_folder."/$json_file.json", 'w');
	fwrite($fp, json_encode($fields));
	fclose($fp);
};
