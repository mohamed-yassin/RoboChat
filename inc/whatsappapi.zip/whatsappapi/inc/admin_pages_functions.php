<?php
function whatsappapi_settings_init(  ) { 

	register_setting( 'pluginPage', 'whatsappapi_settings' );

	add_settings_section(
		'whatsappapi_pluginPage_section', 
		__( 'تفاصيل الاتصالات', 'whatsappapi' ),  // Section title 
		'whatsappapi_settings_section_callback', 
		'pluginPage'
	);

	add_settings_field( 
		'whatsappapi_text_field_0', 
		__( 'رابط ال API ', 'whatsappapi' ), 
		'whatsappapi_text_field_0_render', 
		'pluginPage', 
		'whatsappapi_pluginPage_section' 
	);

	add_settings_field( 
		'whatsappapi_text_field_1', 
		__( 'ال TOKEN ', 'whatsappapi' ), 
		'whatsappapi_text_field_1_render', 
		'pluginPage', 
		'whatsappapi_pluginPage_section' 
	);

	add_settings_field( 
		'whatsappapi_text_field_2', 
		__( 'رقم هاتف مستقبل الرسائل', 'whatsappapi' ), 
		'whatsappapi_text_field_2_render', 
		'pluginPage', 
		'whatsappapi_pluginPage_section' 
    );
    add_settings_field( 
		'whatsappapi_text_field_3', 
		__( 'رقم هاتف مستقبل الرسائل', 'whatsappapi' ), 
		'whatsappapi_text_field_3_render', 
		'pluginPage', 
		'whatsappapi_pluginPage_section' 
	);

}


function whatsappapi_text_field_0_render(  ) { 

	$options = get_option( 'whatsappapi_settings' );
	?>
	<input style="width :  80%" type='text' name='whatsappapi_settings[whatsappapi_text_field_0]' value='<?php echo $options['whatsappapi_text_field_0']; ?>'>
	<?php

}


function whatsappapi_text_field_1_render(  ) { 

	$options = get_option( 'whatsappapi_settings' );
	?>
	<input style="width :  80%" type='text' name='whatsappapi_settings[whatsappapi_text_field_1]' value='<?php echo $options['whatsappapi_text_field_1']; ?>'>
	<?php

}


function whatsappapi_text_field_2_render(  ) { 

	$options = get_option( 'whatsappapi_settings' );
	?>
	<input style="width :  80%" type='text' name='whatsappapi_settings[whatsappapi_text_field_2]' value='<?php echo $options['whatsappapi_text_field_2']; ?>'>
	<?php

}
function whatsappapi_text_field_3_render(  ) { 

	$options = get_option( 'whatsappapi_settings' );
	?>
	<input style="width :  80%" type='text' name='whatsappapi_settings[whatsappapi_text_field_3]' value='<?php echo $options['whatsappapi_text_field_3']; ?>'>
	<?php

}



function whatsappapi_settings_section_callback(  ) { 

	echo __( '', 'whatsappapi' ); //  This section description

}


function whatsapp_login()
{
    $options = get_option( 'whatsappapi_settings' );
    
    $api    = $options['whatsappapi_text_field_0'];
    $token  = $options['whatsappapi_text_field_1'];
    
    $url =  $url = $api.'status?token='.$token;
    $result = file_get_contents($url);
    $result = (array)json_decode($result);
    return $result;
}

function whatsapp_messeges()
{
    $options    = get_option( 'whatsappapi_settings' );
    $api        = $options['whatsappapi_text_field_0'];
    $token      = $options['whatsappapi_text_field_1'];
    
    $url =  $url = $api.'messages?token='.$token;



    $result = file_get_contents($url);
    $result = (array)json_decode($result);
    pre($result['messages']);
    return $result['messages'];

}

function whatsapp_messeges_table(Type $var = null)
{
    $messeges =  whatsapp_messeges() ;
    echo '<br><h2> عرض الرسائل  </h2><table class="wp-list-table widefat fixed striped posts">
            <thead>
                <tr>
                    <th scope="col" id="author" class="manage-column column-author">نص الرساله</th>
                    <th scope="col" id="categories" class="manage-column column-categories">المرسل</th>
                    <th scope="col" id="tags" class="manage-column column-tags">اسم المحادثه</th>
                </tr>
            </thead>
            <tbody id="the-list">';
            foreach($messeges as $key =>$messege){
                $time =  $messege->time ; 
                echo "
                    <tr>
                        <td>$messege->body</td>
                        <td>$messege->senderName</td>
                        <td>$messege->chatName</td>
                    </tr>
                    ";
                }
            echo "</tbody>
        </table>";
}

function whatsapp_send_messege()
{

    $options        = get_option('whatsappapi_settings' );

    $api            = $options['whatsappapi_text_field_0'];
    $token          = $options['whatsappapi_text_field_1'];
    $phone_reciever = $options['whatsappapi_text_field_2'];
    $messege        = $options['whatsappapi_text_field_3'];

    $url            = $url = $api.'sendMessage?token='.$token;

    $data = [
        'phone' => $phone_reciever, // Receivers phone
        'body' => $messege, // Message
    ];
    $json = json_encode($data); // Encode data to JSON

    // Make a POST request
    $options = stream_context_create(['http' => [
            'method'  => 'POST',
            'header'  => 'Content-type: application/json',
            'content' => $json
        ]
    ]);
    // Send a request
    $result = array();
    $result = file_get_contents($url, false, $options);

    echo "<h2>تم تسليم الرساله بنجاح في حاله قمت بارسال الرسائل بشكل متكرر سيستقبل 
    </br>الapi 
    </br>
    الرساله ولكن لن يرسلها شكا في انها ربما تكون 
    </br>ال spam 
    
    </h2>" ;
    
}
function whatsapp_log_out()
{

    $options        = get_option('whatsappapi_settings' );

    $api            = $options['whatsappapi_text_field_0'];
    $token          = $options['whatsappapi_text_field_1'];
    $phone_reciever = $options['whatsappapi_text_field_2'];
    $messege        = $options['whatsappapi_text_field_3'];

    $url            = $url = $api.'logout?token='.$token;

    $data = [

    ];
    $json = json_encode($data); // Encode data to JSON

    // Make a POST request
    $options = stream_context_create(['http' => [
            'method'  => 'POST',
            'header'  => 'Content-type: application/json',
            'content' => $json
        ]
    ]);
    // Send a request
    $result = array();
    $result = file_get_contents($url, false, $options);
    echo '<a href="'.admin_url('admin.php?page=whatsappapi&process=log_out').'" class="button button-primary" > انهاء الجلسه </a>';

    
}
function whatsappapi_form (){ ?>
    <form action='options.php' method='post'>
    <?php
    settings_fields( 'pluginPage' );
    do_settings_sections( 'pluginPage' );
    submit_button('احفظ');
    ?>

</form>
<?php } ; 

function whatsappapi_processes(){ ?>

    <h2>عمليات</h2>
    <a href="<?php echo admin_url('admin.php?page=whatsappapi&process=show_messeges'); ?>" class="button button-primary" > مشاهده الرسائل  </a>
    <a href="<?php echo admin_url('admin.php?page=whatsappapi&process=send_messege'); ?>" class="button button-primary" > ارسال رساله نصيه </a>
    <a href="<?php echo admin_url('admin.php?page=whatsappapi&process=insert_data'); ?>" class="button button-primary" > اعاده ادخال معلومات الاتصال </a>
    <a href="<?php echo admin_url('admin.php?page=whatsappapi&process=log_out'); ?>" class="button button-primary" > انهاء الجلسه </a>

<?php };
function whatsappapi_authen ($qr){
    echo "<h2>تاكد من ادخال البيانات بشكل صحيح وحفظها ثم عمل اسكان للباركود التالي</h2> " ;
    echo '<img src="'.$qr.'" alt="Base64 encoded image"/>';
}


