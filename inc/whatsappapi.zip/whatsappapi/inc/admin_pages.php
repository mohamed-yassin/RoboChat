<?php
add_action( 'admin_menu', 'whatsappapi_add_admin_menu' );
add_action( 'admin_init', 'whatsappapi_settings_init' );


function whatsappapi_add_admin_menu(  ) { 

	add_menu_page( 'whatsappapi', 'whatsappapi', 'manage_options', 'whatsappapi', 'whatsappapi_options_page' );

}

function whatsappapi_options_page(  ) { 
	$login  = whatsapp_login();

	if($login['accountStatus'] == 'authenticated'){
		whatsappapi_processes();
		$process = $_GET['process'] ; 
		if($process != ''){
			if($process== 'send_messege'){
				whatsapp_send_messege();
			}elseif ($process  == 'show_messeges') {
				whatsapp_messeges_table();
			}elseif ($process  == 'log_out') {
				whatsapp_log_out();
			}elseif ($process  == 'insert_data') {
				whatsappapi_form();
			}
		}
	}else {
		whatsappapi_form();
		whatsappapi_authen($login['qrCode']);
	}
}
